GitHub upload instructions:
1. Upload index.html and styles.css to the root of your GitHub repository.
2. In Settings > Pages, publish from the main branch and root folder.
3. Do not upload a .lnk shortcut file. Upload the actual files in this folder.
